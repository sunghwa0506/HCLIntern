package com.travel.api.composite.destination;

import com.travel.api.core.destination.Destination;

import java.util.List;

public class DestinationAggregate {
  private long destId = -1;
  private String place;
  private String country;
  private double latitude;
  private double longitude;
  private String info;
  private String image;

  private  List<RecommendationSummary> recommendations;
  private  List<ReviewSummary> reviews;
  private  List<Destination>destinations;
  private  ServiceAddresses serviceAddresses;


  public DestinationAggregate(long destId, String place,
                              String country, double latitude, double longitude,
                              String info, String image){
    this.destId = destId;
    this.place = place;
    this.country = country;
    this.latitude = latitude;
    this.longitude = longitude;
    this.info = info;
    this.image = image;

  }

  public DestinationAggregate(long destId, String place, String country, double latitude, double longitude,
                              String info, String image, List<RecommendationSummary> recommendations,
                              List<ReviewSummary> reviews, ServiceAddresses serviceAddresses) {
    this.destId = destId;
    this.place = place;
    this.country = country;
    this.latitude = latitude;
    this.longitude = longitude;
    this.info = info;
    this.image = image;
    this.recommendations = recommendations;
    this.reviews = reviews;
    this.serviceAddresses = serviceAddresses;
  }




  public long getDestId() {
    return destId;
  }

  public void setDestId(long destId) {
    this.destId = destId;
  }

  public String getPlace() {
    return place;
  }

  public void setPlace(String place) {
    this.place = place;
  }

  public String getCountry() {
    return country;
  }

  public void setCountry(String country) {
    this.country = country;
  }

  public double getLatitude() {
    return latitude;
  }

  public void setLatitude(double latitude) {
    this.latitude = latitude;
  }

  public double getLongitude() {
    return longitude;
  }

  public void setLongitude(double longitude) {
    this.longitude = longitude;
  }

  public String getInfo() {
    return info;
  }

  public void setInfo(String info) {
    this.info = info;
  }

  public String getImage() {
    return image;
  }

  public void setImage(String image) {
    this.image = image;
  }

  public List<RecommendationSummary> getRecommendations() {
    return recommendations;
  }

  public List<ReviewSummary> getReviews() {
    return reviews;
  }

  public ServiceAddresses getServiceAddresses() {
    return serviceAddresses;
  }

  public List<Destination> getDestinations() {
    return destinations;
  }

  public void setDestinations(List<Destination> destinations) {
    this.destinations = destinations;
  }
}
