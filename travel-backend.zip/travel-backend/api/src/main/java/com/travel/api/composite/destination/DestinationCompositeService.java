package com.travel.api.composite.destination;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

public interface DestinationCompositeService {

  /**
   * Sample usage: "curl $HOST:$PORT/dest-composite/1".
   *
   * @param destId Id of the destination
   * @return the composite destination info, if found, else null
   */
  @GetMapping(
    value = "/dest-composite/{destId}",
    produces = "application/json")
  DestinationAggregate getDestination(@PathVariable long destId);

  @GetMapping(
          value = "/dest-composite/all",
          produces = "application/json")
  ResponseEntity<List<DestinationAggregate>> getAllDestination();
}
