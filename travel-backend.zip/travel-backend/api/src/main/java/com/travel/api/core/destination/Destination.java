package com.travel.api.core.destination;

/**
 * The Type of class is DTO [ Data transfer Object ]
 * As it is used to transfer data between the API implementation and caller
 * 
 */
public class Destination {
    private long destId = -1;
    private String place;
    private String country;
    private double latitude;
    private double longitude;
    private String info;
    private String image;
    private final String serviceAddress;



    public Destination(long destId, String place, String country,
                       double latitude, double longitude, String info,
                       String image, String serviceAddress) {
        this.destId = destId;
        this.place = place;
        this.country = country;
        this.latitude = latitude;
        this.longitude = longitude;
        this.info = info;
        this.image = image;
        this.serviceAddress=serviceAddress;
    }

    public Destination() {
        destId = 0;
        place = null;
        country = null;
        latitude = 0;
        longitude = 0;
        info = null;
        image = null;
        serviceAddress = null;
    }

    public long getDestId() {
        return destId;
    }

    public void setDestId(long destId) {
        this.destId = destId;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getInfo() {
        return info;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public String getServiceAddress() {
        return serviceAddress;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
