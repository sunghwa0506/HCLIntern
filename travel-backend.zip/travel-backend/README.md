# Adding automated microservice tests in isolation
As an exercise Try to add Integration test cases and UT.


`Make sure you have empty application.properties file or make sure only yaml file`
# Some Docker commands cheatsheet
```

kill all running containers with **docker kill $(docker ps -q)**
delete all stopped containers with docker rm $(docker ps -a -q)
delete all images with docker rmi $(docker images -q)
update and stop a container that is in a crash-loop with docker update --restart=no && docker stop
bash shell into container docker exec -i -t /bin/bash - if bash is not available use /bin/sh
bash shell with root if container is running in a different user context docker exec -i -t -u root /bin/bash

```
# Deploy our microservice using Docker
Spring boot creates the following folders after extracting the jars

#### dependencies

#### spring-boot-loader
    spring boot classes, knows how to start spring boot application


snapshot-dependencies -- 


application -- contain application class files and resources

Spring boot docs recommends creating one Docker Layer for each folder.

# Building docker image only for destination-service


```

./gradlew :microservices:destination-service:build
ls -l microservices/destination-service/build/libs

$ ls -l microservices/destination-service/build/libs
total 21176
-rw-r--r-- 1 sujepatr 1049089 _**21678778**_ Oct  4 11:15 destination-service-1.0.0-SNAPSHOT.jar
-rw-r--r-- 1 sujepatr 1049089     3556 Oct  4 11:15 destination-service-1.0.0-SNAPSHOT-plain.jar

 docker build -t destination-service microservices/destination-service

```

# Starting up only one service
```
docker kill $(docker ps -q)
```

# Running the container detached 
`docker run -d -p8080:8080 -e "SPRING_PROFILES_ACTIVE=docker" --name my-dest-srv destination-service `

`docker logs my-dest-srv -f`

`docker rm -f my-dest-srv`

#### Manage microservices using Docker-Compose
Create a docker-compose.yaml inside the parent folder of project.
```
version: '2.1'

services:
  destination:
    build: microservices/destination-service
    mem_limit: 512m
    environment:
      - SPRING_PROFILES_ACTIVE=docker

  recommendation:
    build: microservices/recommendation-service
    mem_limit: 512m
    environment:
      - SPRING_PROFILES_ACTIVE=docker

  review:
    build: microservices/review-service
    mem_limit: 512m
    environment:
      - SPRING_PROFILES_ACTIVE=docker

  destination-composite:
    build: microservices/destination-composite-service
    mem_limit: 512m
    ports:
      - "8080:8080"
    environment:
      - SPRING_PROFILES_ACTIVE=docker

```
The name of the microservice. This will also be the hostname of the container in the internal Docker network.
A build directive that specifies where to find the Dockerfile that was used to build the Docker image.
A memory limit of 512 MB. 512 MB should be sufficient for all our microservices.
The environment variables that will be set up for the container. In our case, we used these to specify which Spring profile to use.

```

./gradlew build
docker-compose build
docker-compose up -d

```

# OpenAPI - Design First approach
Add openAPI docs to project as an assignment.

# Add Persistense
- Protocol Layer handles protocol specific logic. It is very thin , and only consistes of `RestController` 
in the `api` project.
- The `GlobalExceptionHandler` in `util` project.
- The main functionality of each micorservices lies in `Service Layer`.
- The `Destination-composite` service contains an `Integration Layer` ,
  used to handle communication between the other `core` micorservices.
- The `Core` micorservices should have a `Persistance Layer` to communicate with Database.
- Add `Spring Data` as dependency.
- Besides `Spring Data` , we will use a Java bean mapping tool `MapStruct`. 
  It makes easy to transform between spring data entity objects and the API model classes.
- Add dependencies MapStruct, SpringData and JDBC drivers for the database we intend to use.
- Define the spring data entity classes and respository.
- Spring data entity classes and repositories would be placed in a newly created package `persistence`.
- Add MapStruct v1.3.1 in `build.gradle` file or `pom.xml`.
- Since `MapStruct` generates the implementation of the bean mappings at compile time by processing 
`annotaions`.
- for `destination` and `recommendation` use `mongo db
- Use `testcontainers` running automated integration tests.
- Explore `QueryDSL`.



# Kubernets
As a container orchestration , this makes a cluster of server that run containers.
We are as an operator , declare a desired state to the kubernetes cluster by creating objects
using kubernetes API.
Kubernetes always try to keep sync between desired and current state if found any difference.

Main purpose of Kuberntes cluster is to deploy and run containers but also to support
zero downtime rolling upgrades using techniques such as green/blue and canary deployments.

# YAML basic tips and tricks
- 2 spaces should be used for each child of dictionary.
- When we define list of objects inside YAML file then "- "

# Developing Light-weight Microservice using Kubernetes
Single node 
Discovery service is based on kube-proxy , which accepts requests to the DNS name or IP
We can replace Netflix Eureka service .

Helm
---
helm chart can be published . cert-manager 
