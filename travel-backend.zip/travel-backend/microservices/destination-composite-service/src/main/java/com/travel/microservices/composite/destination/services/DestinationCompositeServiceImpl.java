package com.travel.microservices.composite.destination.services;

import com.travel.api.composite.destination.*;
import com.travel.api.core.destination.Destination;
import com.travel.api.core.recommendation.Recommendation;
import com.travel.api.core.review.Review;
import com.travel.api.exceptions.NotFoundException;
import com.travel.microservices.composite.destination.DestinationCompositeServiceApplication;
import com.travel.util.http.ServiceUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@RestController
public class DestinationCompositeServiceImpl implements DestinationCompositeService {
    private final ServiceUtil serviceUtil;
    private DestinationCompositeIntegration integration;

    @Autowired
    public DestinationCompositeServiceImpl(
            ServiceUtil serviceUtil, DestinationCompositeIntegration integration) {

        this.serviceUtil = serviceUtil;
        this.integration = integration;
    }

    @Override
    public DestinationAggregate getDestination(long destId) {

        Destination destination = integration.getDestination(destId);
        if (destination == null) {
            throw new NotFoundException("No product found for productId: " + destId);
        }

        List<Recommendation> recommendations = integration.getRecommendations(destId);

        List<Review> reviews = integration.getReviews(destId);

        return createDestinationAggregate(destination, recommendations, reviews, serviceUtil.getServiceAddress());
    }

    @Override
    public ResponseEntity<List<DestinationAggregate>> getAllDestination() {
        List<Destination>destinations= integration.getAllDestinations();
        // 3. Copy destinations List  info, if available
        List<DestinationAggregate> destinationList=
                (destinations == null) ? null : destinations.stream()
                        .map(d -> new DestinationAggregate(
                                d.getDestId(), d.getPlace(), d.getCountry(),
                                d.getLatitude(),d.getLongitude(),d.getInfo(),
                                d.getImage()))
                        .collect(Collectors.toList());

        return ResponseEntity.ok(destinationList);
    }

    /*@Override
    public DestinationAggregate getAllDestination(long destId) {

    }*/

    private DestinationAggregate createDestinationAggregate(
            Destination destination,
            List<Recommendation> recommendations,
            List<Review> reviews,
            String serviceAddress) {

        // 1. Setup product info
        long destId=destination.getDestId();
        String place= destination.getPlace();
        String country=destination.getCountry();
        double latitude=destination.getLatitude();
        double longitude=destination.getLongitude();
        String info=destination.getInfo();
        String image=destination.getImage();


        // 2. Copy summary recommendation info, if available
        List<RecommendationSummary> recommendationSummaries =
                (recommendations == null) ? null : recommendations.stream()
                        .map(r -> new RecommendationSummary(r.getRecommendationId(), r.getAuthor(), r.getRate()))
                        .collect(Collectors.toList());

        // 3. Copy summary review info, if available
        List<ReviewSummary> reviewSummaries =
                (reviews == null) ? null : reviews.stream()
                        .map(r -> new ReviewSummary(r.getReviewId(), r.getAuthor(), r.getSubject()))
                        .collect(Collectors.toList());

        // 4. Create info regarding the involved microservices addresses
        String destinationAddress = destination.getServiceAddress();
        String reviewAddress = (reviews != null && reviews.size() > 0) ? reviews.get(0).getServiceAddress() : "";
        String recommendationAddress = (recommendations != null && recommendations.size() > 0) ? recommendations.get(0).getServiceAddress() : "";
        ServiceAddresses serviceAddresses = new ServiceAddresses(serviceAddress, destinationAddress, reviewAddress, recommendationAddress);

        return new DestinationAggregate(destId,place,country,longitude,latitude,info,image,
                recommendationSummaries, reviewSummaries, serviceAddresses);
    }
}
