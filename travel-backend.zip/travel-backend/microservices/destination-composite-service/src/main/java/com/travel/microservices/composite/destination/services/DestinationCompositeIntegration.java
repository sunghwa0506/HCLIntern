package com.travel.microservices.composite.destination.services;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.travel.api.core.destination.Destination;
import com.travel.api.core.destination.DestinationService;
import com.travel.api.core.recommendation.Recommendation;
import com.travel.api.core.recommendation.RecommendationService;
import com.travel.api.core.review.Review;
import com.travel.api.core.review.ReviewService;
import static org.springframework.http.HttpMethod.GET;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.travel.api.exceptions.InvalidInputException;
import com.travel.api.exceptions.NotFoundException;
import com.travel.util.http.HttpErrorInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
@Component
public class DestinationCompositeIntegration implements DestinationService, RecommendationService, ReviewService {

    private static final Logger LOG = LoggerFactory.getLogger(DestinationCompositeIntegration.class);

    private final RestTemplate restTemplate;
    private final ObjectMapper mapper;

    private final String destinationServiceUrl;
    //private final String getDestinationServiceUrl;
    private final String recommendationServiceUrl;
    private final String reviewServiceUrl;

    @Autowired
    public DestinationCompositeIntegration(
            RestTemplate restTemplate,
            ObjectMapper mapper,
            @Value("${app.destination-service.host}") String destinationServiceHost,
            @Value("${app.destination-service.port}") int destinationServicePort,
            @Value("${app.recommendation-service.host}") String recommendationServiceHost,
            @Value("${app.recommendation-service.port}") int recommendationServicePort,
            @Value("${app.review-service.host}") String reviewServiceHost,
            @Value("${app.review-service.port}") int reviewServicePort) {

        this.restTemplate = restTemplate;
        this.mapper = mapper;

        destinationServiceUrl = "http://" + destinationServiceHost + ":" + destinationServicePort+"/destinations/";
        //getDestinationServiceUrl = "http://" + destinationServiceHost + ":" + destinationServicePort + "/destinations/";
        recommendationServiceUrl = "http://" + recommendationServiceHost + ":" + recommendationServicePort + "/recommendation?destId=";
        reviewServiceUrl = "http://" + reviewServiceHost + ":" + reviewServicePort + "/review?destId=";
    }




    public Destination getDestination(long destId) {

        try {
            String url = destinationServiceUrl + destId;
            LOG.debug("Will call getDestination API on URL: {}", url);

            Destination destination = restTemplate.getForObject(url, Destination.class);
            LOG.debug("Found a destination with id: {}", destination.getDestId());

            return destination;

        } catch (HttpClientErrorException ex) {

            switch (ex.getStatusCode()) {
                case NOT_FOUND:
                    throw new NotFoundException(getErrorMessage(ex));

                case UNPROCESSABLE_ENTITY:
                    throw new InvalidInputException(getErrorMessage(ex));

                default:
                    LOG.warn("Got an unexpected HTTP error: {}, will rethrow it", ex.getStatusCode());
                    LOG.warn("Error body: {}", ex.getResponseBodyAsString());
                    throw ex;
            }
        }
    }

    @Override
    public List<Destination> getAllDestinations() {
        try {
            String url = destinationServiceUrl+"all";

            LOG.debug("Will call getAllDestinations API on URL: {}", url);
            List<Destination> destinations = restTemplate
                    .exchange(url, GET, null, new ParameterizedTypeReference<List<Destination>>() {})
                    .getBody();

            LOG.debug("Found {} recommendations for a product with id: {}", destinations.size());
            return destinations;

        } catch (Exception ex) {
            LOG.warn("Got an exception while requesting recommendations, return zero recommendations: {}", ex.getMessage());
            return new ArrayList<>();
        }
    }

    private String getErrorMessage(HttpClientErrorException ex) {
        try {
            return mapper.readValue(ex.getResponseBodyAsString(), HttpErrorInfo.class).getMessage();
        } catch (IOException ioex) {
            return ex.getMessage();
        }
    }

    public List<Recommendation> getRecommendations(long destId) {

        try {
            String url = recommendationServiceUrl + destId;

            LOG.debug("Will call getRecommendations API on URL: {}", url);
            List<Recommendation> recommendations = restTemplate
                    .exchange(url, GET, null, new ParameterizedTypeReference<List<Recommendation>>() {})
                    .getBody();

            LOG.debug("Found {} recommendations for a product with id: {}", recommendations.size(), destId);
            return recommendations;

        } catch (Exception ex) {
            LOG.warn("Got an exception while requesting recommendations, return zero recommendations: {}", ex.getMessage());
            return new ArrayList<>();
        }
    }

    public List<Review> getReviews(long destId) {

        try {
            String url = reviewServiceUrl + destId;

            LOG.debug("Will call getReviews API on URL: {}", url);
            List<Review> reviews = restTemplate
                    .exchange(url, GET, null, new ParameterizedTypeReference<List<Review>>() {})
                    .getBody();

            LOG.debug("Found {} reviews for a product with id: {}", reviews.size(), destId);
            return reviews;

        } catch (Exception ex) {
            LOG.warn("Got an exception while requesting reviews, return zero reviews: {}", ex.getMessage());
            return new ArrayList<>();
        }
    }

    /*@Override
    public Destination getDestination(long destId) {
        return null;
    }*/
}