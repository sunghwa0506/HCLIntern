package com.travel.util.http;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * public String destCity(List<List<String>> paths)
 *     {
 *         List<String> endList = new ArrayList<>();
 *         List<String> startList = new ArrayList<>();
 *         for(int i=0;i<paths.size();i++)
 *         {
 *             startList.add(paths.get(i).get(0));
 *             endList.add(paths.get(i).get(1));
 *         }
 *
 *         for(int i=0;i<endList.size();i++)
 *         {
 *             if(!startList.contains(endList.get(i)))
 *                 return endList.get(i);
 *         }
 *         return null;
 *
 *     }
 */
public class TestCode {
    public static void main(String[] args) {
        List<String>dest1=new ArrayList<>();
        dest1.add("London");
        dest1.add("NewYork");
        List<String>dest2=new ArrayList<>();
        dest2.add("NewYork");
        dest2.add("Lima");
        List<String>dest3=new ArrayList<>();
        dest3.add("Lima");
        dest3.add("Sao");
        List<List<String>>paths=new ArrayList<>();
        paths.add(dest1);
        paths.add(dest2);
        paths.add(dest3);
        System.out.println(paths);
        System.out.println(destCity(paths)); ;

    }
    public static String  destCity(List<List<String>> paths) {
        HashMap<String, Boolean> map = new HashMap<>();
        for(List<String> path : paths){
            map.put(path.get(0), false);
            if(map.containsKey(path.get(1))== false){
                map.put(path.get(1), true);
            }

        }
        for(String key : map.keySet()){
            if(map.get(key) == true){
                return key;
            }
        }
        return "";
    }
}

    /**
     *
     * You are given the array paths,
     * where paths[i] = [cityAi, cityBi] means
     * there exists a direct path going from cityAi to cityBi.
     * Return the destination city, that is, the city without any path outgoing to another city.
     * It is guaranteed that the graph of paths forms a line without any loop,
     * therefore, there will be exactly one destination city.
     *  Example 1:
     *    Input: paths = [["London","New York"],["New York","Lima"],["Lima","Sao Paulo"]]
     *         Output: "Sao Paulo"
     *         Explanation: Starting at "London" city you will reach "Sao Paulo"
     *         city which is the destination city.
     *         Your trip consist of: "London" -> "New York" -> "Lima" -> "Sao Paulo".
     */
